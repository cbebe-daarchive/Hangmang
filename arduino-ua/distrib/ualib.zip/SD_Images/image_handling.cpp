/*
  Implementation of functions for SD card image handling.
*/

#include "image_handling.h"

const int SCREEN_WIDTH = 128;
const int SCREEN_HEIGHT = 160;

static int SD_image_in_bounds(int x, int y, SD_Clip_Box *clip);
static int SD_read_pixel_block(Sd2Card *card, uint32_t block_num);
static int is_big_endian(void);
static uint16_t pixel_buffer_read(int block_index);

/*
  Might as well allocate the pixel buffer up front.  We are going to
  need the memory.  It might lead to unpleasant surprises otherwise,
  such as function calls causing the stack to overrun the heap.

  Plus, this will allow us to do more caching which might help cut
  down on SD card read times a bit.
*/

static uint16_t pixel_block[256];     // Block for pixels read from the SD card.
static uint32_t current_pixel_block;  // The current pixel block.
static int current_block_index;  // The index of the current pixel in the block.

SD_Clip_Box SD_get_clip_box(int x, int y, int width, int height) {
  SD_Clip_Box clip;

  clip.x = x;
  clip.y = y;

  clip.width = width;
  clip.height = height;

  return clip;
}

uint16_t SD_image_get_pixel(SD_Img *img, int x, int y) {
  uint16_t pixel;  // The pixel that we are going to be loading.
  
  // First we need to find the tiles which the pixel is located in.
  uint32_t tile_x = x / img->width;
  uint32_t tile_y = y / img->height;

  int in_tile_x = x % img->width;
  int in_tile_y = y % img->height;

  // Check if these tiles are valid for the image...
  if (tile_x > img->x_tiles || tile_y > img->y_tiles) {
    return 0;  // Not in image.  Return a black pixel.
  }


  // How many pixels inside the image the tile is.
  uint32_t pixels_in = img->width * img->height * (tile_x + tile_y * img->x_tiles) + in_tile_x + img->width * in_tile_y;

  // Now we need to get the block which the pixel is in.
  uint32_t block_num = img->start_block + pixels_in / 256; // 256 pixels in a block.

  // Need the index for the pixel location within the block.
  int block_index = pixels_in % 256;  // 256 pixels in a block.
  current_block_index = block_index;  // Set the global block index for reading sequential data.

  // Read in the block which stores the pixel.
  SD_read_pixel_block(&img->card, block_num);

  // Actually read the pixel in from the buffer.
  pixel = pixel_buffer_read(block_index);

  return pixel;
}

uint16_t SD_next_pixel(SD_Img *img) {
  current_block_index++;

  if (current_block_index >= 256) {
    // Need to load the next block
    current_pixel_block++;
    SD_read_pixel_block(&img->card, current_pixel_block);

    // Reset block index
    current_block_index = -1;  // Next pixel will be at 0.
  }

  uint16_t pixel;  // The pixel to load.

  // Actually read the pixel in from the buffer.
  pixel = pixel_buffer_read(current_block_index);

  return pixel;
}

void SD_draw_image(SD_Img *img, Adafruit_ST7735 *tft, int screen_x, int screen_y) {
  // Make a clip box encompassing the entire image.
  SD_Clip_Box clip = SD_get_clip_box(0, 0, img->x_tiles * img->width, img->y_tiles * img->height);

  // Draw the image to the screen.
  SD_draw_image_region(img, tft, screen_x, screen_y, &clip);
}

void SD_draw_image_region(SD_Img *img, Adafruit_ST7735 *tft, int screen_x, int screen_y, SD_Clip_Box *clip) {
  if (screen_x + clip->width > tft->width()) {
    clip->width = tft->width() - screen_x;  // Maximum possible width without going off of the screen.
  }

  if (screen_y + clip->height > tft->height()) {
    clip->height = tft->height() - screen_y;  // Maximum possible height without going off of the screen.
  }

  if (clip->x < 0) {
    clip->x = 0;  // Don't want to go outside of the image.
  }

  if (clip->y < 0) {
    clip->y = 0;  // Don't want to go outside of the image.
  }

  uint16_t pixel;  // Pixel to draw to the screen.

  int start_x_tile = clip->x / img->width;
  int start_y_tile = clip->y / img->height;

  int end_x_tile = (clip->x + clip->width) / img->width;
  int end_y_tile = (clip->y + clip->height) / img->height;

  int img_x, img_y;

  int x_start, y_start;
  int x_end, y_end;

  for (int y_tile = start_y_tile; y_tile < end_y_tile + 1; y_tile++) {
    // May want to start part of the way through the tile.
    // This happens if the region includes only the final portion of the tile.
    if (y_tile == start_y_tile) {
      // First y tile - clip may start part of the way through it.
      y_start = clip->y % img->height;
    }
    else {
      y_start = 0;
    }

    // May want to end part of the way through the tile.
    // This happens if the region includes only the first portion of the tile.
    if (y_tile == end_y_tile) {
      // Last y tile - clip may end part of the way through it.
      y_end = (clip->y + clip->height) % img->height;
    }
    else {
      y_end = img->height;
    }

    for (int x_tile = start_x_tile; x_tile < end_x_tile + 1; x_tile++) {
      // May want to start part of the way through the tile.
      // This happens if the region includes only the final portion of the tile.
      if (x_tile == start_x_tile) {
	// First x tile - clip may start part of the way through it.
	x_start = clip->x % img->width;
      }
      else {
	x_start = 0;
      }

      // May want to end part of the way through the tile.
      // This happens if the region includes only the first portion of the tile.
      if (x_tile == end_x_tile) {
	// Last x tile - clip may end part of the way through it.
	x_end = (clip->x + clip->width) % img->width;
      }
      else {
	x_end = img->width;
      }

      // Want to draw inside of the tile now.
      for (int y = y_start; y < y_end; y++) {
	img_y = y + y_tile * img->height;

	for (int x = x_start; x < x_end; x++) {
	  img_x = x + x_tile * img->width;

	  if (x == x_start || y == y_start) {
	    // In this case we need to set the starting location for drawing pixels.
	    pixel = SD_image_get_pixel(img, img_x, img_y);	    
	  }
	  else {
	    // Next pixel should be the next pixel in the block (or possibly the next block over).
	    pixel = SD_next_pixel(img);
	  }

	  // Now just draw the pixel to the screen
	  tft->drawPixel(screen_x + img_x - clip->x, screen_y + img_y - clip->y, pixel);
	}
      }
    }
  }
}

void SD_draw_image_frame(SD_Img *img, Adafruit_ST7735 *tft, int screen_x, int screen_y, SD_Clip_Box *clip) {
  // Want to draw a coloured frame around the image.
}

static int SD_image_in_bounds(int x, int y, SD_Clip_Box *clip) {
  if (x >= clip->x && x < clip->x + clip->width) {
    // Okay, point is within the appropriate x range to be in the boundaries.
    if (y >= clip->y && y < clip->y + clip->height) {
      // Point is also within the y range.
      return 1;  // Point is in the boundaries, return true.
    }
  }

  return 0;  // Point is not within the boundaries.
}

static int SD_read_pixel_block(Sd2Card *card, uint32_t block_num) {
  // Check if a block read is necessary.
  if (block_num != current_pixel_block) {
    current_pixel_block = block_num;  // Need to reset the current block.

    // May have an error code.
    return card->readBlock(block_num, (uint8_t*) pixel_block);
  }

  // Block is already loaded, return 1 because nothing terrible happened.
  return 1;
}

static int is_big_endian(void) {
  int val = 1;
  char *c = (char *) &val;

  if (c[0] == 1) {
    // If the lower byte equals 1, then it is little endian.
    return 0;
  }
  else {
    // Lower byte does not equal 1.  Machine is big endian.
    return 0;
  }
}

static uint16_t pixel_buffer_read(int block_index) {
  uint16_t pixel;  // Pixel that we are reading from the buffer and returning.

  // May need to correct for endianness.  This should be little endian for mega2560 Arduinos.
  if (is_big_endian()) {
    pixel = ((uint8_t*)pixel_block)[block_index * 2 + 1];
    pixel = pixel << 8;
    pixel = pixel | ((uint8_t*)pixel_block)[block_index * 2];
  }
  else {
    pixel = ((uint8_t*)pixel_block)[block_index * 2];
    pixel = pixel << 8;
    pixel = pixel | ((uint8_t*)pixel_block)[block_index * 2 + 1];
  }

  return pixel;
}
