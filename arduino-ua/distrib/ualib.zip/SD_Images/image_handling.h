/*
Functions for handling images on the SD cards.  Mostly just straight binary 565 colour data.
 */

#ifndef IMAGE_HANDLING_H
#define IMAGE_HANDLING_H


#include <Adafruit_GFX.h>    // Core graphics library
#include <Adafruit_ST7735.h> // Hardware-specific library
#include <SD.h>
#include <SPI.h>
// #include "mem_syms.h"

// Color definitions
#define	BLACK           0x0000
#define	BLUE            0x001F
#define	RED             0xF800
#define	GREEN           0x07E0
#define CYAN            0x07FF
#define MAGENTA         0xF81F
#define YELLOW          0xFFE0 
#define WHITE           0xFFFF

extern const int SCREEN_WIDTH;
extern const int SCREEN_HEIGHT;

/*
 Basic structure for representing an image stored on the SD card.

 The images on the SD card are to be stored as 16-bit 565 colour values.  The
 image may either be a single tile, or consist of many smaller tiles, with each
 one in a row being adjacent in memory.

 Note: These images MUST start at the beginning of a block on an SD card.
 */

typedef struct SD_Img {
  // SD card information
  Sd2Card card;  // The SD card to read the image from.
  uint32_t start_block;  // The starting address of the image on the SD card.

  // Image information
  uint32_t x_tiles;  // Number of tiles in the x dimension.
  uint32_t y_tiles;  // Number of tiles in the y dimension.

  // Dimensions
  uint32_t width;   // Width of one tile.
  uint32_t height;  // Height of one tile.

} SD_Img;

/*
 Structure for an axis-aligned box to specify the region on an image
 to actually draw to the screen.

 */

typedef struct SD_Clip_Box {
  // Top left corner.
  int x;  // Lowest x coordinate of the box.
  int y;  // Lowest y coordinate of the box.

  // Dimensions.
  int width;   // Width of the box (x-axis).
  int height;  // Height of the box (y-axis).

} SD_Clip_Box;

// Functions

SD_Clip_Box SD_get_clip_box(int x, int y, int width, int height);

/*
 Function to get the colour value of a pixel in an image given x and y
 coordinates.

 Arguments:
 -SD_Img *img:  The image to load the pixel from.
 -int x:  The x coordinate of the pixel in the image.
 -int y:  The y coordinate of the pixel in the image.

 Preconditions:  The x and y coordinates must actually be within the image,
                 otherwise the return value is a black pixel.

 Postconditions:  Returns a 16-bit 565 colour value ready to print to a screen.
 */

uint16_t SD_image_get_pixel(SD_Img *img, int x, int y);

/*
 Function to draw an image from the SD card onto the screen.

 Arguments:
 -SD_Img *img:  The image to draw the image from.
 -Adafruit_ST7735 *tft:  The display to draw the image on.
 -int screen_x:  The x position on the screen to start drawing the image.
 -int screen_y:  The y position on the screen to start drawing the image.

 Preconditions:  None.

 Postconditions:  Will attempt to draw the entire image to the screen.

 */

void SD_draw_image(SD_Img *img, Adafruit_ST7735 *tft, int screen_x, int screen_y);

/*
 Function to draw an image from the SD card onto the screen, but
 also ignore pixels which are not in a clip region (which is rectangular).

 Arguments:
 -SD_Img *img:  The image to draw the image from.
 -Adafruit_ST7735 *tft:  The display to draw the image on.
 -int screen_x:  The x position on the screen to start drawing the image.
 -int screen_y:  The y position on the screen to start drawing the image.
 -SD_Clip_Box *clip:  Pointer to the clipping box for the image.

 Preconditions:  None.

 Postconditions: Draws the region inside of the clip box to the screen.
                 The clipping box has coordinates which correspond to the
		 pixels inside of the image.
 */

void SD_draw_image_region(SD_Img *img, Adafruit_ST7735 *tft, int screen_x, int screen_y, SD_Clip_Box *clip);

#endif
