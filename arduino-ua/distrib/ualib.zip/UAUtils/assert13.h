#ifndef _assert13_h
#define _assert13_h
void assert13(int invariant, int code);
#endif
